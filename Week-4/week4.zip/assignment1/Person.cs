﻿class Person
{
    public string name;
    public string city;
    public int age;
}