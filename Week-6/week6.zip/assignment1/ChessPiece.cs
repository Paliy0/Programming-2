﻿using System;
using System.Collections.Generic;

namespace assignment1
{
    class ChessPiece
    {
        public ChessPieceColor color;
        public ChessPieceType type;
    }
}
