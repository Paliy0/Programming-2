﻿using System;
using System.Collections.Generic;

namespace assignment1
{
    public enum ChessPieceColor { Black, White }

    public enum ChessPieceType { Pawn = 'p', Rook = 'r', Knight = 'k', Bishop = 'b', King = 'K', Queen = 'Q'}
}

