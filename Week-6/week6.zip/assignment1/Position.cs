﻿using System;
using System.Collections.Generic;

namespace assignment1
{
    class Position
    {
        public int fieldRow;
        public int fieldColumn;
    }
}
