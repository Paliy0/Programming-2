﻿class StateElectors
{
    public string StateName;
    public int ElectorsCount;
}