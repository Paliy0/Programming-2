﻿using System;
using System.Collections.Generic;
using System.Text;

namespace assignment3
{
    class PoliticalPartyResult
    {
        public string Name;
        public int TotalVotes;
        public int NrOFSeats;
    }
}
