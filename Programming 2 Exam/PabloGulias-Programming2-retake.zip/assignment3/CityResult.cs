﻿using System;
using System.Collections.Generic;
using System.Text;

namespace assignment3
{
    class CityResult
    {
        public string CityName;
        public int TotalVotes;
        public int[] PartyVotes;
    }
}
