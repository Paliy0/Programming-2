﻿using System;

namespace CandyCrusher
{
    public enum RegularCandies { JellyBean = 1, Lozenge, LemonDrop, GumSquare, LollipopHead, JujubeCluster }
}